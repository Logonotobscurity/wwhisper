# Implementation Prompt 04 — Evidence and Learning

Implement the evidence, correction, and failure-case loop.

## Objective

Turn conversational corrections into scoped learning artifacts.

## Requirements

Create:

- provenance-bearing knowledge records
- correction records
- failure cases
- regression-case serialization

When a user corrects the system:

1. acknowledge the correction
2. update the current conversation state
3. identify the missing dimension
4. optionally create a failure case
5. never generalize the correction into a population-wide cultural rule automatically

## Failure case

Minimum fields:

- failure_type
- input
- agent_interpretation
- user_correction
- missing_dimension
- context
- regression_test

## Acceptance

A correction can be replayed as a regression test.

The system can distinguish:

- user-provided evidence
- validated reference
- source-derived evidence
- disputed evidence
- unavailable evidence
