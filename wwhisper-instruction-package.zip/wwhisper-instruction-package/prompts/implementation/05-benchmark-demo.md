# Implementation Prompt 05 — Benchmark and Demo

Implement the first research benchmark and demo.

## Objective

Prove the core thesis with a small controlled evaluation.

## Build

1. 20–30 benchmark cases.
2. Four conditions:
   - generic baseline
   - structured baseline
   - DAPF
   - naive culturalization
3. Scoring rubric.
4. Replay runner.
5. Regression runner.
6. Demo telemetry.

## Metrics

Record separately:

- interpretation confidence
- context sufficiency
- evidence coverage
- discourse alignment
- cultural relevance
- action clarity
- clarification quality
- appropriateness
- respect
- over-culturalization
- response length

## Demo

Implement one complete delayed-delivery scenario.

The showcase behavior must be:

```text
ambiguous input
→ uncertainty detected
→ concise clarification
→ user explanation
→ repair
→ useful action
→ failure/evaluation event
```

## Constraint

Do not make claims of statistical significance from the initial small benchmark.

The benchmark is an engineering/research instrument, not evidence of universal cultural superiority.
