# Implementation Prompt 02 — Semantic Core

Implement the DAPF semantic core without connecting to AssemblyAI yet.

## Objective

Build:

```text
conversation state
→ DAPF decision
→ audit
→ response action
```

## Requirements

### DAPF

Implement an orchestrator that evaluates:

- task
- audience
- relationship/register
- linguistic mode
- known context
- missing context
- cultural relevance
- evidence
- uncertainty

It must be able to select `NONE`.

### Auditor

Implement an independent audit function.

It must identify:

- missing context
- alternative interpretations
- evidence gaps
- representation risks
- discourse mismatch
- fabricated/unsupported cultural references

### Decision engine

Map audit + DAPF state to:

- ANSWER
- CLARIFY
- REPAIR
- MULTIPLE_INTERPRETATIONS
- ESCALATE

## Tests

At minimum:

1. explicit business request → ANSWER
2. material ambiguity → CLARIFY
3. unsupported cultural reference → avoid reference
4. high interpretation confidence + low context sufficiency → CLARIFY
5. user correction → REPAIR
6. culturally themed but irrelevant case → NONE

Do not expose chain-of-thought.
