# Implementation Prompt 01 — Bootstrap

You are implementing `wwhisper` from an empty repository.

## Objective

Create the smallest production-shaped TypeScript project that can support the architecture in `docs/03-SYSTEM-ARCHITECTURE.md`.

## Requirements

1. Read `AGENTS.md`.
2. Create a TypeScript Node project.
3. Add formatting, linting, type checking, and test infrastructure.
4. Create the directory structure from `README.md`.
5. Create environment validation with:
   - `ASSEMBLYAI_API_KEY`
   - `PORT`
   - optional model/provider configuration
6. Create typed domain contracts for:
   - conversation state
   - DAPF decision
   - audit result
   - knowledge record
   - correction
   - failure case
   - evaluation event
7. Keep provider-specific types under `src/voice/assemblyai`.
8. Do not implement the voice WebSocket yet.
9. Add unit tests proving the core contracts can be created and validated.
10. Update README with exact local setup commands.

## Acceptance criteria

- project installs cleanly
- typecheck passes
- tests pass
- lint passes
- no secrets are committed
- no placeholder architecture claims are presented as implemented behavior
