# Implementation Prompt 03 — AssemblyAI Voice Layer

Implement the realtime AssemblyAI adapter.

## Before coding

Read the current AssemblyAI Voice Agent API documentation:

- https://www.assemblyai.com/docs/voice-agents/voice-agent-api
- https://www.assemblyai.com/docs/voice-agents/voice-agent-api/session-configuration
- https://www.assemblyai.com/docs/voice-agents/voice-agent-api/events-reference

Do not rely on remembered API details.

## Objective

Implement:

```text
microphone/audio
→ AssemblyAI WebSocket
→ normalized internal events
→ semantic core
→ response/tool actions
→ AssemblyAI
```

## Requirements

- isolate WebSocket code
- handle session lifecycle
- handle partial and final user transcripts
- handle agent transcripts
- handle reply audio
- handle interruptions
- handle tool calls
- handle session errors
- handle reconnect/session resume according to current docs
- never expose API keys to browser clients
- keep provider event types separate from internal domain events

## Tool surface

Start with:

- `analyze_conversation`
- `audit_interpretation`
- `record_correction`
- `record_failure_case`

Use the current AssemblyAI tool schema exactly.

## Acceptance

A local voice session can:

1. connect
2. become ready
3. receive user speech
4. produce a final transcript
5. invoke semantic processing
6. generate a response
7. speak the response
8. survive an interruption
9. log a structured event
