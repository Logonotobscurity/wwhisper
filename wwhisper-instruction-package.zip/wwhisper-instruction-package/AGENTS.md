# AGENTS.md

## Mission

Build `wwhisper` as a research-grade, demoable discourse-adaptive voice agent on top of AssemblyAI's Voice Agent API.

The product claim is deliberately narrow:

> The agent can detect when conventional AI may be missing culturally or contextually significant meaning.

Do not turn this into a generic chatbot, a generic customer-support bot, or a culture-themed prompt wrapper.

## Source of truth

Before changing AssemblyAI integration code, consult the current AssemblyAI Voice Agent API documentation. Do not rely on remembered event names, payload shapes, authentication behavior, audio formats, or tool semantics.

Official references:

- https://www.assemblyai.com/docs/voice-agents/voice-agent-api
- https://www.assemblyai.com/docs/voice-agents/voice-agent-api/session-configuration
- https://www.assemblyai.com/docs/voice-agents/voice-agent-api/events-reference
- https://www.assemblyai.com/docs/coding-agent-prompts

## Architecture invariants

1. AssemblyAI owns realtime voice transport, STT, TTS, turn detection, interruptions, and session mechanics.
2. `wwhisper` owns semantic interpretation and adaptation.
3. Culture is contextual evidence, never a demographic shortcut.
4. The DAPF engine must be allowed to select `NONE`.
5. User corrections are evidence about the current interaction, not universal cultural truth.
6. Every cultural reference requires provenance or explicit user-provided grounding.
7. Interpretation confidence and context sufficiency are separate dimensions.
8. The auditor is allowed to disagree with the interpreter.
9. The system must prefer clarification over confident invention when uncertainty is material.
10. Internal reasoning must be represented as structured decision state, not exposed as chain-of-thought.
11. Every new behavior should have a regression test when practical.
12. Keep the first demo narrow and reliable.

## Engineering rules

- TypeScript is the default implementation language unless a documented reason requires otherwise.
- Prefer small modules with explicit interfaces.
- Validate external inputs at boundaries.
- Keep AssemblyAI protocol types isolated under `src/voice/assemblyai`.
- Keep DAPF logic provider-agnostic.
- Keep prompts versioned and readable as Markdown.
- Never hardcode secrets.
- Never log API keys or raw sensitive audio.
- Use structured event logs.
- Make uncertainty explicit.
- Avoid hidden global state.
- Avoid premature abstractions.
- Avoid adding dependencies unless they solve a concrete requirement.

## DAPF policy

DAPF evaluates:

- task grounding
- audience context
- relationship/register
- linguistic mode
- conversational goal
- known and missing context
- cultural relevance
- evidence/provenance
- uncertainty
- discourse strategy

Candidate strategies include:

`DIRECT`, `CLARIFY`, `QUESTION_FIRST`, `ANALOGY`, `STORY_FIRST`, `COMMUNITY_REFERENCE`, `PROVERB`, `MULTIPLE_INTERPRETATIONS`, `REPAIR`, `ESCALATE`, `NONE`.

The system must be able to select `NONE`.

Never infer a discourse strategy solely from ethnicity, nationality, language, name, location, or demographic profile.

## Audit policy

The epistemic auditor checks for:

- missing context
- alternative interpretations
- unsupported certainty
- evidence gaps
- representation gaps
- discourse mismatch
- demographic assumptions
- fabricated cultural references
- inappropriate proverb/story use
- unjustified claims of completeness

A plausible answer is not automatically a sufficient answer.

## Voice behavior

Spoken responses should be:

- concise
- natural
- interruption-tolerant
- action-oriented
- honest about uncertainty

Ask one useful clarification at a time.

## Tool-calling rule

AssemblyAI tool definitions and event handling must follow the current API contract. In particular, do not invent nested tool schemas or event payloads. Test tool-call interruption behavior explicitly.

## Required implementation sequence

Use the prompts in `prompts/implementation/` in order.

Do not jump to a dashboard before the core voice → DAPF → audit → decision loop works.

## Definition of done for MVP

A user can speak to the agent, the system can detect an ambiguous/culturally loaded utterance, choose to clarify instead of guessing, receive the user's clarification, repair its interpretation, produce a concise spoken answer, and record the event for evaluation/regression.

## Change discipline

For every significant change:

1. State the invariant being preserved.
2. Implement the smallest coherent change.
3. Add/update tests.
4. Run the relevant checks.
5. Update the relevant documentation.
6. Record unresolved limitations.

Do not silently weaken research claims to make tests pass.
