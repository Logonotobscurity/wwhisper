# Prompt Architecture

Prompts are versioned artifacts, not scattered strings.

## Layers

```text
Constitution
  ↓
Core Voice System
  ↓
DAPF Orchestrator
  ↓
Epistemic Auditor
  ↓
Decision / Repair
  ↓
Response Generator
```

## Prompt responsibilities

### Constitution

Defines non-negotiable behavior.

### System

Defines the agent's role and voice.

### DAPF orchestrator

Produces structured decision state.

### Auditor

Challenges interpretation independently.

### Decision/repair

Chooses answer, clarification, repair, or escalation.

### Response generator

Converts decision state into natural speech.

## Prompt rule

The final response generator should receive the decision state required to respond. It should not receive hidden chain-of-thought.

## Prompt versioning

Each prompt should have:

- purpose
- input contract
- output contract
- invariants
- examples
- failure modes
- version identifier

Changes to prompts should be evaluated against regression cases.
