# Conversation Model

## Turn lifecycle

```text
INPUT_STARTED
→ PARTIAL_TRANSCRIPT
→ FINAL_TRANSCRIPT
→ CONTEXT_UPDATE
→ DAPF_DECISION
→ AUDIT
→ RESPONSE_DECISION
→ RESPONSE
→ FEEDBACK
```

## Conversation state

Minimum state:

- session ID
- turn ID
- latest user utterance
- current task
- audience/relationship context
- language mode
- known context
- unresolved ambiguity
- DAPF decision
- audit result
- response action
- correction events
- failure cases
- timestamps/latency telemetry

## State rules

1. Do not let stale context silently become current fact.
2. Distinguish user-provided facts from model inferences.
3. Mark unresolved ambiguity explicitly.
4. Keep provider-specific event payloads out of the semantic state model.
5. Make state serializable for replay and evaluation.

## Interruptions

A voice interruption can invalidate pending response work.

The integration must distinguish:

- generated but not spoken
- spoken
- interrupted
- superseded

Do not record interrupted tool results as completed conversational actions.
