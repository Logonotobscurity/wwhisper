# Problem Definition

## The failure mode

Most voice agents optimize for:

1. transcription
2. intent detection
3. answer generation

That pipeline can work well for explicit requests but can fail when meaning is distributed across context.

Examples include:

- idioms
- code-switching
- indirect disagreement
- culturally situated references
- relationship-dependent language
- business norms not stated explicitly
- emotionally loaded statements

The dangerous failure is not simply “the model got the translation wrong.”

It is:

> The model did not know that it was missing something.

## Why this matters

A fluent answer can still be:

- incomplete
- socially inappropriate
- overly literal
- patronizing
- culturally performative
- unsupported by evidence
- operationally wrong

## Design response

`wwhisper` adds an explicit intermediate decision layer.

Instead of:

```text
utterance → answer
```

the system becomes:

```text
utterance
→ context assessment
→ discourse strategy assessment
→ evidence/uncertainty audit
→ decision
→ response
```

## Key distinction

Interpretation confidence is not context sufficiency.

An agent may be 90% confident about the literal interpretation while having only 40% confidence that it has enough context to act on that interpretation.

That distinction is foundational to the system.
