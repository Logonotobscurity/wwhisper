# Research Thesis

## Central hypothesis

Discourse-adaptive prompting can improve the contextual appropriateness of voice-agent responses when the system explicitly evaluates task, audience, linguistic mode, evidence, uncertainty, and discourse strategy before responding.

## Competing explanations

A convincing evaluation must separate DAPF from:

- generic prompt improvement
- increased verbosity
- narrative vividness
- forced cultural references
- better instruction following
- simple clarification behavior

## Experimental conditions

### A — Generic baseline

A conventional voice-agent prompt with no explicit discourse-adaptation policy.

### B — Structured baseline

Adds task, audience, objective, and action-close structure.

### C — DAPF

Adds explicit contextual assessment, discourse strategy selection, evidence/provenance checks, uncertainty separation, and repair behavior.

### D — Naive culturalization control

Forces culturally themed behavior, such as frequent proverb/story usage, regardless of contextual evidence.

This condition is important because it tests whether cultural adaptation is actually adaptive.

## Primary metrics

- comprehension
- interpretation quality
- contextual sufficiency
- evidence coverage
- discourse alignment
- action clarity
- perceived appropriateness
- perceived respect
- over-culturalization
- clarification quality

## Required reporting

Do not collapse all metrics into one “culture score”.

Report where DAPF improves, where it does not, and where it introduces costs.

## Falsification

The thesis should be considered weakened if:

- DAPF does not outperform structured prompting on contextual cases
- the naive culturalization control performs equally well without higher over-culturalization
- improvements disappear when verbosity is controlled
- gains occur only because DAPF asks more questions
