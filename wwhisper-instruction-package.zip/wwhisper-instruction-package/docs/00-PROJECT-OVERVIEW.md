# Project Overview

## What is wwhisper?

`wwhisper` is a discourse-adaptive voice-agent research prototype.

It sits on top of a managed realtime voice layer and adds a semantic control system that asks:

> What might the agent be missing before it decides how to respond?

The system is designed for situations where literal language understanding is insufficient because meaning depends on context, relationship, register, code-switching, local conventions, or culturally situated references.

## Product proposition

A voice agent that knows when it might be missing something.

## Research proposition

A useful cultural adaptation system should not maximize cultural references. It should maximize appropriate contextual adaptation while minimizing performative or unsupported culturalization.

## MVP scenario

A small-business operator is discussing a delayed B2B delivery.

The agent may receive:

- direct business language
- code-switched language
- ambiguous idioms
- culturally situated expressions
- emotional language
- corrections from the speaker

The system should determine whether it can answer, should clarify, or needs another repair path.

## Success condition

The system should demonstrate that it can choose:

> “I may be missing what you mean. Can you clarify whether you're talking about effort, luck, fairness, or something else?”

instead of confidently producing a wrong interpretation.

## Research boundary

The MVP does not claim that Yoruba, Igbo, Hausa, or any other group has one discourse style. It evaluates specific language/context cases with explicit evidence and records uncertainty.

## Technology boundary

AssemblyAI is the realtime voice infrastructure.

`wwhisper` is the semantic adaptation layer.
