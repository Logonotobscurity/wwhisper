# Roadmap

## Phase 0 — Repository bootstrap

- project structure
- AGENTS.md
- contracts
- prompts
- tests
- environment setup

## Phase 1 — Semantic core

- conversation state
- DAPF schema
- DAPF orchestrator
- audit result
- decision engine

## Phase 2 — Voice

- AssemblyAI WebSocket adapter
- session lifecycle
- transcripts
- audio
- tool calls
- interruptions
- reconnect/resume

## Phase 3 — Evidence

- provenance records
- validated references
- correction records
- failure cases

## Phase 4 — Evaluation

- benchmark
- four conditions
- metrics
- regression runner

## Phase 5 — Demo

- voice UI
- telemetry
- scenario replay
- evaluation display

## Phase 6 — Hardening

- security
- latency
- error handling
- documentation
- submission package

## Explicitly later

Do not prioritize before the MVP:

- large knowledge graphs
- broad multilingual coverage
- model fine-tuning
- autonomous business actions
- large multi-agent orchestration
- production-scale analytics
