# Hackathon Demo

## Demo objective

Show one behavior that is difficult to fake with a generic chatbot:

> The agent recognizes when it may be missing context and changes its behavior.

## Demo sequence

### 1. Normal request

User asks for help responding to a delayed delivery.

Agent responds directly.

### 2. Ambiguous/culturally situated utterance

User introduces a phrase whose meaning depends on context.

Agent detects uncertainty.

### 3. Clarification

Agent asks one concise question.

### 4. User correction/context

User explains what they intended.

### 5. Repair

Agent updates interpretation and responds appropriately.

### 6. Telemetry

Show:

- interpretation confidence
- context sufficiency
- evidence coverage
- discourse alignment
- selected strategy
- action
- audit flags

Do not show chain-of-thought.

### 7. Learning artifact

Show the resulting failure case/regression item.

## Demo failure policy

If live behavior becomes unreliable, use a deterministic replay mode.

A reliable research demo is better than a fragile “AI magic” demo.

## Judge takeaway

The key contrast should be:

```text
Generic agent:
confidently answers

wwhisper:
detects missing context → asks → learns from correction → repairs
```
