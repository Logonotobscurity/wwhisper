# DAPF Specification

DAPF = Discourse-Adaptive Prompting Framework.

## Decision dimensions

### 1. Task grounding

Capture:

- domain
- user goal
- stakes
- requested outcome

### 2. Audience context

Capture:

- speaker role
- counterparty role
- relationship
- register
- situational setting

### 3. Linguistic mode

Capture:

- primary language
- code-switching
- formality
- dialect/variant when explicitly supported
- uncertain language signals

### 4. Discourse strategy

Candidate values:

- `DIRECT`
- `CLARIFY`
- `QUESTION_FIRST`
- `ANALOGY`
- `STORY_FIRST`
- `COMMUNITY_REFERENCE`
- `PROVERB`
- `MULTIPLE_INTERPRETATIONS`
- `REPAIR`
- `ESCALATE`
- `NONE`

### 5. Cultural grounding

A cultural reference must have:

- a reason for relevance
- a reference type
- provenance
- confidence/status

Evidence status:

- `validated`
- `user_provided`
- `source_derived`
- `unavailable`
- `disputed`

### 6. Action close

Every business interaction should end with a useful next step unless the user explicitly asks for exploration only.

## Mandatory rule

The framework must be able to select `NONE`.

A culturally themed response is not inherently a culturally appropriate response.

## Uncertainty dimensions

Track separately:

- `interpretation_confidence`
- `context_sufficiency`
- `evidence_coverage`
- `discourse_alignment`
- `cultural_relevance`

All are normalized to 0–1 for evaluation.

## Decision rule

If interpretation confidence is high but context sufficiency or evidence coverage is materially low, the system should not treat the answer as fully grounded.

## Example

Input:

> “No be by who hustle pass na him go get money.”

Possible interpretations:

- effort does not guarantee financial outcome
- fairness is being questioned
- luck/opportunity matters
- the speaker is rejecting a simplistic success narrative

If the business consequence depends on which interpretation is intended, ask.

Do not automatically insert a proverb merely because the utterance is culturally situated.
