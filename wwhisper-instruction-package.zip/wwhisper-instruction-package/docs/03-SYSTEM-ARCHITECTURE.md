# System Architecture

## High-level flow

```text
Speaker
  ↓
AssemblyAI Voice Agent API
  ↓
Transcript / session events
  ↓
Conversation State
  ↓
DAPF Orchestrator
  ├── Task Grounding
  ├── Audience Context
  ├── Linguistic Mode
  ├── Discourse Strategy
  └── Cultural Grounding
  ↓
Epistemic Auditor
  ├── Coverage
  ├── Evidence
  ├── Representation
  └── Frame Challenge
  ↓
Decision Engine
  ├── ANSWER
  ├── CLARIFY
  ├── REPAIR
  ├── MULTIPLE_INTERPRETATIONS
  └── ESCALATE
  ↓
Response Generator
  ↓
AssemblyAI Voice Agent API
  ↓
Speaker
```

## Ownership boundary

### AssemblyAI

Owns:

- realtime WebSocket transport
- speech recognition
- voice synthesis
- turn detection
- barge-in/interruption behavior
- session lifecycle
- tool-call transport

### wwhisper

Owns:

- conversation state
- DAPF decisions
- evidence/provenance
- uncertainty
- auditing
- correction handling
- failure-case recording
- evaluation
- regression

The AssemblyAI integration should remain replaceable.

## Core services

### Voice adapter

Normalizes provider events into internal events.

### Conversation state

Maintains the current turn, speaker intent, known context, unresolved ambiguity, and decision state.

### DAPF

Selects the appropriate discourse strategy.

### Auditor

Independently challenges the interpretation.

### Decision engine

Converts structured state into a response action.

### Knowledge layer

Stores provenance-bearing evidence and user corrections.

### Evaluation layer

Turns conversations and failure cases into measurable tests.

## Why not multi-agent?

Multiple independent LLM agents are unnecessary for the MVP and introduce:

- latency
- coordination failures
- harder debugging
- higher cost
- ambiguous responsibility

DAPF and auditing should initially be deterministic orchestration around focused model calls/tools rather than an agent swarm.
