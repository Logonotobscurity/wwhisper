# Evaluation

## Goal

Determine whether DAPF improves contextual appropriateness rather than merely making responses longer or more culturally decorated.

## Conditions

A. Generic baseline

B. Structured baseline

C. DAPF

D. Naive culturalization

## Metrics

### Interpretation quality

Did the agent correctly identify the intended meaning?

### Context sufficiency

Did the agent have enough context to act?

### Evidence coverage

Were material claims grounded?

### Discourse alignment

Did the response strategy fit the interaction?

### Action clarity

Could the user identify what to do next?

### Appropriateness

Was the response socially and contextually suitable?

### Respect

Did the user perceive the response as respectful rather than performative?

### Over-culturalization

Did the system insert unnecessary cultural references?

### Clarification quality

When clarification was needed, did the question efficiently resolve the ambiguity?

## Important control

Measure response length.

If DAPF wins only because it produces longer answers, the claim is weakened.

## Evaluation unit

A benchmark item should include:

- scenario
- speaker utterance
- intended interpretation
- relevant context
- intentionally missing context
- acceptable response behavior
- unacceptable behaviors
- condition
- evaluator rubric

## Statistical discipline

Do not claim causal improvement from a tiny convenience sample.

Report:

- sample size
- evaluator method
- inter-rater agreement when applicable
- confidence intervals where appropriate
- limitations
