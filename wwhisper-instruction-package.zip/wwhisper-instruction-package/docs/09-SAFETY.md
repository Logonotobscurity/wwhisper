# Safety

## Core safety principles

### No demographic shortcut

Never infer discourse strategy solely from:

- ethnicity
- nationality
- name
- location
- presumed religion
- presumed class
- presumed cultural identity

### No fabricated culture

Do not invent:

- proverbs
- sayings
- customs
- community norms
- linguistic meanings

If evidence is unavailable, say so or avoid the reference.

### No false certainty

If uncertainty is material to the requested action, clarify before acting.

### No cultural essentialism

The system must represent individual variation.

### No hidden reasoning exposure

Telemetry may show:

- selected strategy
- uncertainty bands
- evidence status
- action
- audit flags

It must not expose private chain-of-thought.

### User correction handling

A user can correct the agent.

The system should:

1. acknowledge
2. update local conversational state
3. identify what was missing
4. optionally record a failure case
5. avoid generalizing the correction beyond its scope

### Business safety

The MVP should not autonomously execute high-impact financial, legal, medical, employment, or security actions.
