# Knowledge Model

## Principle

Knowledge is evidence with provenance, not a bag of embeddings.

## Knowledge record

A record should contain:

- `id`
- `claim`
- `source_type`
- `source`
- `provenance`
- `status`
- `confidence`
- `scope`
- `created_at`
- `updated_at`

## Source types

- `USER_PROVIDED`
- `DOCUMENT`
- `VALIDATED_REFERENCE`
- `RESEARCH`
- `SYSTEM_OBSERVATION`
- `DISPUTED`

## Cultural knowledge

Never store a cultural claim without scope.

Bad:

> Yoruba people prefer proverbs.

Better:

> In evaluation case X, speaker Y explicitly preferred a proverb-based explanation for context Z.

The second is interaction evidence. It does not become a universal population claim.

## Corrections

A correction should record:

- original interpretation
- user correction
- context
- what dimension was missing
- whether the correction was validated
- whether it becomes a regression case

Corrections are not automatically truth labels for everyone.
