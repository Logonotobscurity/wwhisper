# Benchmark

## Benchmark purpose

The benchmark tests whether the agent recognizes when literal or fluent interpretation is insufficient.

## Item categories

1. Explicit business request
2. Ambiguous idiom
3. Code-switched request
4. Indirect disagreement
5. Emotionally loaded expression
6. Culturally situated reference
7. False cultural cue
8. User correction
9. Missing context
10. Unnecessary culturalization trap

## Required item fields

```json
{
  "id": "case-001",
  "scenario": "...",
  "utterance": "...",
  "language_mode": "...",
  "known_context": [],
  "missing_context": [],
  "gold_interpretation": "...",
  "acceptable_actions": ["CLARIFY"],
  "forbidden_behaviors": [
    "invent cultural explanation",
    "pretend certainty"
  ]
}
```

## Initial benchmark

Start with 20–30 carefully authored cases.

Do not start with hundreds of synthetic cases.

Quality and adjudication matter more than volume for the first demo.

## Regression rule

Every confirmed failure that represents a reusable behavior should become a regression item.

## Dataset governance

Do not publish personal information from real conversations.

Do not treat user corrections as automatically representative of an entire language or culture.
