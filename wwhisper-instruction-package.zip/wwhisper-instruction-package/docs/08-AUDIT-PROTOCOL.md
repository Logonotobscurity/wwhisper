# Audit Protocol

The epistemic auditor is an independent challenge layer.

## Audit questions

### Coverage

What relevant context might be missing?

### Evidence

Which claims are grounded, inferred, or unsupported?

### Representation

Is the interpretation relying on an unsupported demographic assumption?

### Discourse alignment

Does the chosen response strategy fit the interaction?

### Cultural grounding

Is a cultural reference:

- relevant?
- grounded?
- appropriately scoped?
- necessary?

### Alternatives

Are there plausible interpretations that would materially change the answer?

## Auditor output

Minimum fields:

- `status`
- `issues`
- `missing_context`
- `alternative_interpretations`
- `evidence_gaps`
- `representation_risks`
- `discourse_risks`
- `recommended_action`

## Independence

The auditor should receive the proposed interpretation as an object to critique, not as an instruction to defend.

## No manufactured disagreement

The auditor should not invent a problem simply to appear independent.

If the interpretation is well-supported, the auditor should say so.
